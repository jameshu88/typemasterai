document.addEventListener('DOMContentLoaded', function() {
    chrome.tabs.executeScript({
        code: 'window.getSelection().toString();'
    }, function(selection) {
        var wordCount = selection[0].split(/\s+/).filter(function(n) { return n != '' }).length;
        document.getElementById('count').textContent = wordCount;
    });
});